Hangman
=======

OOP implementation of the word game.
